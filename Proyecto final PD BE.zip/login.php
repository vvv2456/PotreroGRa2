<?php

$usuario = $_POST ["usuario"];

$contrasenia = $_POST ["contrasenia"];

$ckuser = "damian";
$ckpass = "argentina2026";

if ($usuario==$ckuser && $contrasenia==$ckpass) {
    header ("location:Movicel.php");
}
else {
    header ("location:error.html");
}

?>