<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Tienda de celulares</h1>
        <button type="submit"><a href="Movicel.php">Inicio</a></button>
        <button type="submit"><a href="lista_productos.php">Lista de celulares</a></button>
        <button type="submit"><a href="agregar_productos.html">Agregar mas productos</a></button>
    <h2>Lista de celulares</h2>
    <p>La siguiente lista muestra los celulares en stock</p>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Marca</th>
            <th>modelo</th>
            <th>almacenamiento</th>
            <th>color</th>
            <th>stock</th>
            <th>precio</th>
        </tr>

        <?php
        //1) conexion con PHP
        $conexion=mysqli_connect("127.0.0.1","root", "");
    mysqli_select_db($conexion, "base_movicel");

        //2) orden SQL 
        //SELECT * (todo) nombre de tabla
        //SELECT campos y tabla FROM nombre de tabla
        $consulta= "SELECT * from celulares";

        //3) ejecutar orden
        $datos= mysqli_query ($conexion, $consulta);

        //4) datos de la orden
          while ($reg=mysqli_fetch_array($datos)) { ?>
        <tr>
            <td><?php echo $reg['id']; ?></td>
            <td><?php echo $reg['marca']; ?></td>
            <td><?php echo $reg['modelo']; ?></td>
            <td><?php echo $reg['almacenamiento']; ?></td>
            <td><?php echo $reg['color']; ?></td>
            <td><?php echo $reg['stock']; ?></td>
            <td><?php echo $reg['precio']; ?></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>