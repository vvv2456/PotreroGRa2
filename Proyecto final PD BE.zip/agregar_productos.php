<?php
        //1) conexion con PHP
        $conexion=mysqli_connect("127.0.0.1","root", "");
    mysqli_select_db($conexion, "base_movicel");
        //2) orden SQL 
        $consulta= "celulares";

        //2) almacenar datos de envio POST
        // Crear variables para cada dato para la base de datos
        $marca = $_POST ['marca'];
        $modelo = $_POST ['modelo'];
        $almacenamiento = $_POST ['almacenamiento'];
        $color = $_POST ['color'];
        $stock = $_POST ['stock'];
        $precio = $_POST ['precio'];

        //3) preparar orden SQL 
        // INSERT INTO nombre_tabla (campos_tabla) VALUES (valores_a_ingresar)
        // => Ingresa dentro de la siguiente tabla los siguientes valores
        // a) generar la consulta a realizar
        $consulta= "INSERT INTO celulares (id,marca,modelo,almacenamiento,color,stock,precio)
        VALUES ('','$marca','$modelo','$almacenamiento','$color','$stock','$precio')";

        //4) ejecutar la consulta
    $datos = mysqli_query($conexion,$consulta);
  // a) redirigir a index
  header('location: lista_productos.php');
?>