<!DOCTYPE html>
<html lang="en">
<head>
    <title>Tienda Movicel</title>
    <link rel="stylesheet" href="Movicel_estilos.css">
</head>

<body>
    <nav class="menuPrincipal">
        <a href="movicel.php" target="_blank">
            <img src="ruta/del/logo-movicel.png" alt="Logo Movicel" style="width:180px;">
        </a>
        <a href="Movicel.php">Tienda</a>
        <a href="lista_productos.php">Productos</a>
        <a href="importados.html">Importaciones</a>
        <a href="login.html">Login</a>
    </nav>
    <header>
        <h1>Tienda Movicel</h1>
    </header>

    <div class="slide">
        <ul class="slider">
            <li id="slide1">
                <h1>Tienda online de celulares</h1>
                <img src="https://media.losandes.com.ar/p/9affcaa25bc5a15f421f3e3b953069fc/adjuntos/368/imagenes/100/088/0100088047/1000x0/smart/mitos-los-telefonos-celulares.jpg" />
            </li>
            <li id="slide2">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSH92s4RZcBoqCMB9QQmB2n8F9adc0fflmbV9T9Huj4_-1hmMZ4k-hXus8&s=10" />
            </li>
            <li id="slide3">
                <img src="https://i.blogs.es/1c0816/captura-de-pantalla-2022-08-08-a-las-9.26.21/450_1000.jpeg" />
            </li>
        </ul>

        <ul class="menu">
            <li>
                <a href="#slide1">1</a>
            </li>
            <li>
                <a href="#slide2">2</a>
            </li>
            <li>
                <a href="#slide3">3</a>
            </li>
        </ul>
    </div>

    <!--seccion novedades-->
    <section>
        <h2>Celulares insignia</h2>
        <p>Los celulares mas destacados del mercado</p>
        <div class="cards">
            <div class="card">
                <img src="https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcTbmB2XqYIvP0s60UeLz6J0ybVaJlEMR50zH1tYqvfVs-8y2s_qJHqIX6UBmL4mgU9tp0glaHZGCzw2tJI3KoXCjWSQtecRktPs5fsQSOefJ9uEwfdkqoIRNg&usqp=CAc" alt="imagen">
                <h2>Samsung S26 Ultra</h2>
                <p>(1)</p>
                <a href="lista_productos.php" class="boton">Comprar <?php $consulta= 'SELECT Marca FROM celulares WHERE Samsung';?></a>
            </div> 
            <div class="card">                
                <img src="data:image/webp;base64,UklGRtAIAABXRUJQVlA4IMQIAADQLgCdASqTALQAPp1InkslpCKhpbPbyLATiWUA1XTZv9HSX00XbImrnqTxzlI8vWT/2f/J57PrP2EOlb6OH65GXpE+h7Xzx2IZHhKlHPUFPE/lAZjIvP6x6onbZOTZ0Y3mjSstOoCYcdQZpNvKgIOWqvVLBb4OUwCrTwKNAuFcW6LlBw5VdrDYYWlrOf2SNIagfpTh4YEGhIsqlJXTI258w/NBgm5IjOW57dfX3rHVsaFCRbNLu1JHEwuPAG5YQKC0nXJGGMP2ZnrPcIcYIUgaEE1kWKYc3rc96GAE88FpfaTXZCEqlYn8z4Q8ldY/k5xMPvYulX/pbvyxK9W/NgAQ/73FkqUIiI8218oUKkwjAqhVqI/EdtUN0PZs/zeDIyV54IKUaQlQxa/bHf7tfTU3LjFQf+YQ8ZhLEhwMjkJFsQJuyMwqH+DATdhGlAMdYYsMq+X1IhfGrErkICgwLQ4OM3PPnf3goEAYAdSP67/RjxEQQrefWpQfOW7r+rExgAD++l6bhFDdHv496A7Z+mTjNF83wL3R5yXBuv0f1nL+zpLVf7Zr8l4XOoE2KTQ/M63dAywGevaz8HUFJzUnFIthKYN8bseUW2jgo1mIXlm2e9nnjdiJAjTutYObYfof7jdv2PxoDBFtq9iHa/Xj9kcbxUcAzB+zxT+JjLdBhOfZkAdwsnkeHCYvd4ryN8K/hS13Q96bO1lRbTcJMmXOzzxF3npZ4Z6Yrt0I5gBf/uTreSAF4VaOrzn9jnaLunroezkipw3PzFQ713mubQEiFE+R1bcc7ywmyZ9QSTb/OAf2WmjrRso2e6cI7fzNtXo5g46ykVBmOmg5RIM1UWBkblkeTp/01x9AU3MH872/H/UbvPMAA16wgg7v9eurRG1zD2P6INz5wvGcTDFF1qYJSvj33oPvUUctfl5WoGiMRblsLwmQaUcOEBRL+HcPZPncZS+aYtIVUQCfzOokoNuD0WWO9AiZbM1ezklPYcTTR8JxZA0ZhE1T/5vcI30iO2KMkQaSLS9S8stiW+rytzoe2h4TUyeuP9SeOHA9x0qNSeyXHLRKrDTq1cPOx586R2hPxWvEq1/ZjzF24o/Pbsis21coPe+mK5nLHNJCHZqBsIEVXU3FE0RK/tfKcrsoxCzNPUZ+r5e9UJVULh9GdnDJwkuD8xG7mavJZla1m/jxP+uOlfKnTCVywQ2tPFauxWDaU2HtHLT0BH2/1LmtQjW4i01dJMK9WdZy/yFFepaK5MLMM2kZI5OOKlVbaCIjuy9LeX/8W17dfo+2P7q8J6vtOVqFINXMXejl6it2DK/QnQPUl74xKJT0AhJ21fo6kp2tU1l0gW/W5cCnBd/87zPE9Aag+ZdkgE+z0ZHgwd4dZyqqgXKq95rSnlJRoPlJgCW6AAY/h6rIIZ8su0rF4Tbs9SEGo1PfWYwSj2DEmXEDyLihF9rvnmzfTPSxpGjf7Dp79x3BrNovFv/7w4S6MiB4+M/qqA3Pwt6809YbQ1wK+rTsuADaMGgYro7xvzb8cFoD0wkKb4T+QMuXlI7C3qQ1T90HNOgqqKO5c2n7S7gbuRgm6pg5gDaObPOkm+nJyb4XG4+r2y1lbz35P6uyn59jxa8wr3uP7pj45BBfjXkGnMm2PgCQb3pCvy+jM8yui+wWnIf0NssPLrSHG3zkyYMMPFxIXL4bDwohfmA7P5AOYboWM3/l6oVE3jlOzLJCSCwUKIKtwYMU0FxA0nR2kxPQu44aX6Kv2j/FCxEf/MX20x/4JrjrpO3x96X9D+i7zwX06RUkawJM2iyeWe+xHIDzwOHMpTEfnNjt0Ju3aSX7XVG5IaqnzSlgDI0Tb9SVXukV/HxfG+5hBgBR1dhC40mlWyA3TbZJRaP3wX7K2IsP6gCEymtb7GVFSINpmLm40dg/4En17E7nW2od9dhahRZ2eF/L9NUJerNoRvavArzMFI6FY9BAZLZ+y+Esq9FKgbORj7ZUAQToUsCXDz4jyqmcq8ryEdsaQBkMzerhrt4f6YPd+EBqF9Lq9vY6JveVS6MyixH63QfdX9LMGmsg/uG/aB2D5WfASAuTnY3yuPf2ZHHNAHsMrP7JMmVbpQXGrcJIFC36x7a9nBqeRg/cyA48DaJrvvHisvVvEZ+qLJGa37Bt6RSX/kB/luY07bSYbZrgVTQF5Yg1tBIlUre89viu8KF+6Quf+QKkRzW2X8KeLbVEA/SJHPgUjQ/RHTj61XV00cwyAqPQP9QE7y0icVV5T0I+hOxgUarmZIrLctbeBSyS0s1PMWqrm8N1Pjc4BjZ8olxWB1XyW+V7RPuSRrQS56tMAjJ+J0UrUDzNgRf7HtK9wnoWaKn1hL5lYktXvxHJrAJTS4azqgoWY2KOPbvmWuGezcnq3O8gno1g4Ph7uHWi3vCaLoj3BCmerPAsPJWcr8B3TTOWF8rbUPa9F4C4TqPEWj9E3P3Ut4fTtNKvvn9LAhpUYLm4FL5hqp/dX0LpeWSeZBweJFyOjT7V3Xc+QcD5PMIppygNZrW6cOMYCUuQgEwkQmHhNlZieidlQLvjFosUedaeK1te8ZXw9+xarDZNgZa5vZzWdfDzNhlFGfz1D3uIkWyb9STlof2rn/yc7vqI0GoYa9bO8GZAXhccX/oACWsBwjhyPOGHPwGnjjXOBld4ZlGhNFc6pOEU765KbaQQJlehPBzHU120IVTwMrRrm01vySr+KWMVWaV7Qfl6ni2Ah1wA0iBJrvqHtpxkyDiQfV+Yrctbn9S7xg72DI27Y3UFbMuka3+6HMLN4lalm+wDj4jUHjDZKWFtiitUOIXoteWGcsK8BwsV2BRDbtXKd2hG+hjNIOvc1Dkjz4nbGTjbkHv9JzOX2L7UvzdpqAe3keSJJIOGiOY9qKFkDp5EIBMTBpLRXHEbigI/2axMTEARf2s/+VqV/Je/+SRvuiIhPm4h4QBS3aUEmrLckRAYsfkDm2NIIm/OLc1J4AAAAAAAAAA=" alt="imagen">
                <h2>I-phone 17/pro/pro max</h2> 
                <p>(2)</p>               
                <a href="lista_productos.php" class="boton">Comprar <?php $consulta= 'SELECT Apple FROM celulares WHERE Marca';?></a>
            </div>
            <div class="card">
                <img src="https://th.bing.com/th/id/OIP.Lk0FVDhYNZ05uaa-Wkq0VwHaEI?w=303&h=180&c=7&r=0&o=7&pid=1.7&rm=3" alt="imagen">
                <h2>Xiaomi 15 Ultra</h2>
                <p>(3)</p>
                <a href="lista_productos.php" class="boton">Comprar <?php $consulta= "SELECT 'Marca' FROM 'celulares' WHERE 'Xiaomi'";?></a>
            </div>
        </div>
    </section>

    <!--seccion guia-->
    <section>
        <h2>Guía de celulares</h2>
        <p>Podemos ayudarte a encontrar el celular que buscas</p>
        <div class="cards">
            <div class="card">
                <img src="https://www.clarin.com/img/2022/09/15/ggl0rT8w0_1200x630__1.jpg" alt="imagen">
                <h2>Los mejores telefonos</h2>
                <p>>(10 al 15)</p>
                <a href="lista_productos.php" class="boton">Leer mas</a>
                
            </div>
            <div class="card">
                <img src="https://th.bing.com/th/id/OIP.-l3xiugYDaQa71ImMNizDQHaE0?w=248&h=180&c=7&r=0&o=7&pid=1.7&rm=3" alt="imagen">
                <h2>Los telefonos con mejor camara</h2>
                <p>>(17 al 21)</p>
                <a href="lista_productos.php" class="boton">Leer mas</a>
            </div>
            <div class="card">
                <img src="https://th.bing.com/th/id/OIP.gV91MP2x0tNUUkWXmGMpuQHaEK?w=292&h=180&c=7&r=0&o=7&pid=1.7&rm=3" alt="imagen">
                <h2>Los telefonos de entrada</h2>
                <p>>(22 al 26)</p>
                <a href="lista_productos.php" class="boton">Leer mas</a>
            </div>
        </div>
    </section>

    <!--seccion importados-->
    <section>
        <h2>Importaciones</h2>
        <p>Podemos ayudarte a importar los celulares mas dificiles de conseguir</p>
        <div class= slide>
            <ul class= slider>
                <li id= slide1>
                    <img src="https://tse4.mm.bing.net/th/id/OIP.8ZOvWeoo5KqghyWPJVreJwAAAA?r=0&rs=1&pid=ImgDetMain&o=7&rm=3" alt="imagen">
                    <a href="Importados.html" class="boton">Saber mas</a>
                </li>
                <li id= slide2>
                    <img src="https://th.bing.com/th/id/OIP.Uc83nWf1BtEoD-S_J_3D9gHaEK?w=287&h=180&c=7&r=0&o=7&pid=1.7&rm=3" alt="imagen">
                    <a href="Importados.html" class="boton">Saber mas</a>
                </li>
            </ul>

            <ul class="menu">
                <li>
                    <a href="#slide1">1</a>
                </li>
                <li>
                    <a href="#slide2">2</a>
                </li>
            </ul>
        </div>
    </section>

    <!--seccion redes sociales-->
    <section>
        <h2>Contactos</h2>
        <p>Facebook: Tienda Movicel</p>
        <p>Instagram; Tienda_Movicelok</p>
        <p>X; Somos Movicel</p>
        <p>WhatsApp: 11-1234-5678</p>
        <p>Correo Electronico: Movicelok@gmail.com</p>
    </section>

    <footer>
        <p>© 2026 Tienda Movicel. Todos los derechos reservados.</p>
    </footer>
</body>
</html>