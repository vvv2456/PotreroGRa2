<?php

$usuario = $_POST ["usuario"];
$contrasenia = $_POST ["contrasenia"];
$ckuser = "linea caba";
$ckpass = "xvz007";

if ($usuario==$ckuser and $contrasenia==$ckpass) {
    header ("location:https://buenosaires.gob.ar/inicio/");
}
else {
    header ("location:error.html");
}

?>